const { Sequelize } = require('sequelize');
var sequelize = new Sequelize('epfoacwk', 'epfoacwk', 'RnOnvN78uwx5_k80FQ9SBBUNvR81mVSL', {
    host: 'batyr.db.elephantsql.com', // Just the host name
    dialect: 'postgres',
    port: 5432,
    dialectOptions: {
        ssl: { rejectUnauthorized: false }
    },
    query: { raw: true }
});

const Student = sequelize.define('Student', {
    studentNum: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    firstName: {
        type: Sequelize.STRING,
        allowNull: false
    },
    lastName: {
        type: Sequelize.STRING,
        allowNull: false
    },
    email: Sequelize.STRING,
    addressStreet: Sequelize.STRING,
    addressCity: Sequelize.STRING,
    addressProvince: Sequelize.STRING,
    TA: Sequelize.BOOLEAN,
    status: Sequelize.STRING
});

const Course = sequelize.define('Course', {
    courseId: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    courseCode: Sequelize.STRING,
    courseDescription: Sequelize.STRING
});

Course.hasMany(Student, { foreignKey: 'course' });

const { DataTypes } = require('sequelize');

function initialize() {
    return sequelize.sync()
        .then(() => {
            console.log('Database synced successfully.');
        })
        .catch(error => {
            console.error('Error syncing the database:', error); // Add this line
            throw new Error('Unable to sync the database: ' + error);
        });
}


function addStudent(studentData) {
    studentData.TA = studentData.TA ? true : false;

    for (const key in studentData) {
        if (studentData[key] === '') {
            studentData[key] = null;
        }
    }

    return Student.create(studentData)
        .catch(() => {
            throw new Error('Unable to create student');
        });
}

function getAllStudents() {
    return Student.findAll()
        .then(students => {
            console.log("Retrieved students:", students); // Add this line to check retrieved students
            return students;
        })
        .catch(() => {
            throw new Error('No students available');
        });
}

function getTAs() {
    return new Promise((resolve, reject) => {
        if (dataCollection && dataCollection.students.length > 0) {
            const tas = dataCollection.students.filter(student => student.TA);
            resolve(tas);
        } else {
            resolve([]); // Return an empty array if no TAs are available
        }
    });
}

function getCourses() {
    return Course.findAll()
        .then(courses => courses)
        .catch(() => {
            throw new Error('No courses available');
        });
}

function addCourse(courseData) {
    // Ensure blank values are set to null
    for (const key in courseData) {
        if (courseData.hasOwnProperty(key) && courseData[key] === "") {
            courseData[key] = null;
        }
    }

    return Course.create(courseData)
        .then(() => {
            // Refresh dataCollection with updated data from the database
            return Course.findAll()
                .then(courses => {
                    dataCollection.courses = courses;
                });
        });
}

function updateCourse(courseData) {
    // Ensure blank values are set to null
    for (const key in courseData) {
        if (courseData.hasOwnProperty(key) && courseData[key] === "") {
            courseData[key] = null;
        }
    }

    return Course.update(courseData, {
        where: {
            courseId: courseData.courseId
        }
    })
        .then(() => {
            // Refresh dataCollection with updated data from the database
            return Course.findAll()
                .then(courses => {
                    dataCollection.courses = courses;
                });
        });
}

function deleteCourseById(id) {
    return Course.destroy({
        where: {
            courseId: id
        }
    });
}

function getStudentsByCourse(course) {
    return Student.findAll({
        where: { course }
    })
        .then(students => students)
        .catch(() => {
            throw new Error('No results returned');
        });
}

function getStudentByNum(num) {
    return Student.findOne({
        where: { studentNum: num }
    })
        .then(student => student)
        .catch(() => {
            throw new Error('No results returned');
        });
}

function getCourseById(id) {
    return Course.findOne({
        where: { courseId: id }
    })
        .then(course => course)
        .catch(() => {
            throw new Error('No results returned');
        });
}

function updateStudent(studentData) {
    studentData.TA = studentData.TA ? true : false;

    for (const key in studentData) {
        if (studentData[key] === '') {
            studentData[key] = null;
        }
    }

    return Student.update(studentData, {
        where: {
            studentNum: studentData.studentNum
        }
    })
        .catch(() => {
            throw new Error('Unable to update student');
        });
}

function deleteStudentByNum(studentNum) {
    return Student.destroy({
        where: {
            studentNum: studentNum
        }
    });
}

module.exports = {
    initialize,
    addStudent,
    getAllStudents,
    getTAs,
    getCourses,
    getStudentsByCourse,
    getStudentByNum,
    getCourseById,
    updateStudent,
    addCourse,
    updateCourse,
    deleteCourseById,
    deleteStudentByNum
};
